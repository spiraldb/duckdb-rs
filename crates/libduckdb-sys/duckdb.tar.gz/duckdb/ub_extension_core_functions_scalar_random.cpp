#include "extension/core_functions/scalar/random/random.cpp"

#include "extension/core_functions/scalar/random/setseed.cpp"

