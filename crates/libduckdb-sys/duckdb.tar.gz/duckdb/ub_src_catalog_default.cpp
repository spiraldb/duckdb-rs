#include "src/catalog/default/default_functions.cpp"

#include "src/catalog/default/default_generator.cpp"

#include "src/catalog/default/default_schemas.cpp"

#include "src/catalog/default/default_table_functions.cpp"

#include "src/catalog/default/default_types.cpp"

#include "src/catalog/default/default_views.cpp"

